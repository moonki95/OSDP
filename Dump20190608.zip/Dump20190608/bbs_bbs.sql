-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: bbs
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bbs`
--

DROP TABLE IF EXISTS `bbs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `bbs` (
  `bbsID` int(11) NOT NULL,
  `bbsTitle` varchar(50) DEFAULT NULL,
  `userID` varchar(20) DEFAULT NULL,
  `bbsDate` datetime DEFAULT NULL,
  `bbsContent` varchar(2048) DEFAULT NULL,
  `bbsView` int(11) DEFAULT NULL,
  `bbsAvailable` int(11) DEFAULT NULL,
  PRIMARY KEY (`bbsID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bbs`
--

LOCK TABLES `bbs` WRITE;
/*!40000 ALTER TABLE `bbs` DISABLE KEYS */;
INSERT INTO `bbs` VALUES (1,'asdf','mkjang0905','2019-05-29 01:24:06','asdf',0,1),(2,'ddd','moonki','2019-05-29 14:14:53','dd',0,1),(3,'asfdasdf3132123','moonki','2019-05-29 14:15:25','asdfasdfasfdasf23123',0,1),(4,'safd','moonki','2019-05-29 14:17:18','asdf',0,1),(5,'d','moonki','2019-05-29 14:39:19','d',0,1),(6,'ㄴㄹㅇ','moonki','2019-05-29 14:52:42','ㅁㄹㅇ',0,1),(7,'ㅁㄹㄴ','moonki','2019-05-29 14:52:45','ㅁㄹㅇ',0,1),(8,'ㅋㅌ','moonki','2019-05-29 14:52:48','ㅊㅍㅋㅌㅊㅍ',2,1),(9,'ㅂㅈㄱㅂㅈㄱ','moonki','2019-05-29 14:52:51','ㅈㄱㄷㅂㅈㄱ',0,0),(10,'ㅂㅆ','moonki','2019-05-29 14:52:55','ㅆ',0,0),(11,'ㅗ','moonki','2019-05-29 14:52:59','ㅗ',0,0),(12,'qwreqwr','mkjang0905','2019-05-29 20:18:11','asfasfasdf\r\n342134\r\n1243@!$@!$\r\n2#!$!@#$',1,1),(13,'<script>alert(\'hello world\')</script>','mkjang0905','2019-05-29 20:22:25','dd',1,1),(14,'qwerqerw','moonki','2019-05-29 21:31:32','eqwfsd',1,0),(15,'rweqwer','moonki','2019-05-29 23:45:17','qrewqer',1,1),(16,'[BEST] [BEST] [BEST] [BEST] [BEST] [BEST] sfd','moonki','2019-05-30 11:40:57','afsdf',0,0),(17,'fasdㄹㄴㅇㄴㅁㄹㅇㄴㄹㅇㅁㄴㄹㅇㅁㄴㄹㅇ','moonki','2019-05-30 11:44:04','afsdㅇㅁㄴㅇㄹㄹㄴㅇㄴㅇㄹㅁㄴㅇㄹㅁㅇㄹ',0,1),(18,'제발','moonki','2019-05-30 16:05:38','돼',16,1),(19,'asfdsf','moonki','2019-06-07 15:42:33','sfdsd',0,0),(20,'ㅂㅈ','moonki','2019-06-08 16:14:31','ㅂㅈ',21,1),(21,'ㅁㄹㅈㄷㄱ','moonki','2019-06-08 16:16:07','ㅂㄱㄷㅂㅈㄱ',17,1),(22,'[BEST] [BEST] [BEST] [BEST] [BEST] [BEST] ㅌㅌㅌ','moonki','2019-06-08 16:25:05','ㅌㅌ',0,0),(23,'ㅇㅇ','moonki','2019-06-08 16:25:15','ㅇㅇ',0,1),(24,'ㄴ','moonki','2019-06-08 16:25:19','ㄴㄴ',12,1),(25,'[BEST] [BEST] [BEST] [BEST] [BEST] [BEST] ㅁㄴㄹㅇ','moonki','2019-06-08 16:28:18','ㅁㄴㅇㄹ',0,0),(26,'[BEST] [BEST] [BEST] [BEST] [BEST] [BEST] ert','moonki','2019-06-08 17:03:25','wert',0,0);
/*!40000 ALTER TABLE `bbs` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-06-08 19:19:54
