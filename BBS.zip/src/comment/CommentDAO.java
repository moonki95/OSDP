package comment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import bbs.Bbs;

public class CommentDAO {
   private Connection conn;
   private ResultSet rs;

   public CommentDAO() {
      try {
         String dbURL = "jdbc:mysql://localhost:3306/BBS?serverTimezone=UTC";
         String dbID = "root";
         String dbPassword = "1234";
         Class.forName("com.mysql.jdbc.Driver");
         conn = DriverManager.getConnection(dbURL, dbID, dbPassword);
      } catch (Exception e) {
         e.printStackTrace();
      }
   }
   
   public String getDate() {   //SQL 상의 현재시간을 가져오는 메소드
      String SQL ="SELECT NOW()";
      try {
         PreparedStatement pstmt = conn.prepareStatement(SQL); //conn 객체를 이용해 SQL 실행하기위한 준비환경을 만들어준다.
         rs = pstmt.executeQuery();   //그 결과값은 rs에 저장.
         
         if(rs.next()) {   
            return rs.getString(1);   //현재 날짜를 가져온다
         }
      }catch(Exception e) {
         e.printStackTrace();
      }
      return "";
   }
   
   public int getNext() {   //게시글 번호는 primary key 이며 하나씩 증가해야함.
      String SQL = "SELECT commentID FROM comment ORDER BY commentID DESC";   //comment 테이블 안의 commentID를  내림차순 정렬후 마지막 번호를 가져오고 ==가장 최신걸 가져오고
      try {
         PreparedStatement pstmt = conn.prepareStatement(SQL);
         rs = pstmt.executeQuery();
         if (rs.next()) {
            return rs.getInt(1) + 1;      //가져온 번호의 +1 한 값을 반환.
         }
         return 1; // 쓰여진 댓글이 없다면 == 지금 쓰는게 첫 댓글이면 1을 반환.
      } catch (Exception e) {
         e.printStackTrace();
      }
      return -1; //-1은 게시글 작성시의 오류
   }
   
   public int writeComment(int bbsID, String userID, String commentContent ) {
      String SQL = "INSERT INTO comment VALUES (?, ?, ?, ?, ?, ?)";
      try {
         PreparedStatement pstmt = conn.prepareStatement(SQL);   //여기까진 그대로
         pstmt.setInt(1, bbsID);   //bbsID
         pstmt.setInt(2, getNext());   //commentID
         pstmt.setString(3, userID); 
         pstmt.setString(4, getDate());
         pstmt.setString(5, commentContent);
         pstmt.setInt(6, 1);
         return pstmt.executeUpdate();
      } catch (Exception e) {
         e.printStackTrace();
      }
      return -1;//
   }
   
   /*댓글을 불러오기*/
   
public ArrayList<Comment> getList(int bbsID) {   //pageNumber 대신 Bbsid를 준다.
      String SQL = "SELECT * FROM COMMENT WHERE bbsID = ? AND commentAvailable";
      ArrayList<Comment> list = new ArrayList<Comment>();
      try {
         PreparedStatement pstmt = conn.prepareStatement(SQL);
         pstmt.setInt(1, bbsID);
         rs = pstmt.executeQuery();
         while (rs.next()) {
            Comment comment = new Comment();
            comment.setBbsID(rs.getInt(1));
            comment.setCommentID(rs.getInt(2));
            comment.setUserID(rs.getString(3)); 
            comment.setCommentDate(rs.getString(4));
            comment.setCommentContent(rs.getString(5));
            comment.setCommentAvailable(rs.getInt(6));
            list.add(comment);
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
      return list;
   }
   /*
   public boolean nextPage(int pageNumber) { //�럹�씠吏� : �삁)寃뚯떆湲��씠 15媛쒕㈃ �럹�씠吏��뒗 2媛쒓� �걹.
      String SQL = "SELECT * FROM BBS WHERE bbsID < ? AND bbsAvailable = 1 ORDER BY bbsID DESC LIMIT 10";
      try {
         PreparedStatement pstmt = conn.prepareStatement(SQL);
         pstmt.setInt(1, getNext() - (pageNumber - 1) * 10);
         rs = pstmt.executeQuery();
         if (rs.next()) {
            return true;
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
      return false;
   }
   
   */
   public Comment getComment(int bbsID) {
      String SQL = "SELECT * FROM comment WHERE bbsID = ?";
      try {
         PreparedStatement pstmt = conn.prepareStatement(SQL);
         pstmt.setInt(1, bbsID);
         rs = pstmt.executeQuery();
         if (rs.next()) {
            Comment comment = new Comment();
            comment.setBbsID(rs.getInt(1));
            comment.setCommentID(rs.getInt(2));
            comment.setUserID(rs.getString(3));
            comment.setCommentDate(rs.getString(4));
            comment.setCommentContent(rs.getString(5));
            comment.setCommentAvailable(rs.getInt(6));
            return comment;
         }
      } catch (Exception e) {
         e.printStackTrace();
      }
      return null;
   }
   
   public int update(int commentID, String commentContent) { //湲� �닔�젙
      String SQL = "UPDATE COMMENT SET commentContent = ? where commentID = ?";
      try {
         PreparedStatement pstmt = conn.prepareStatement(SQL);   //여기까진 그대로
         pstmt.setString(1, commentContent );
         pstmt.setInt(2, commentID);   //commentID
         return pstmt.executeUpdate();
      } catch (Exception e) {
         e.printStackTrace();
      }
      return -1;//
   }
   
   
   public int delete(int commentID) {
      String SQL = "UPDATE COMMENT SET commentAvailable = 0 WHERE commentID = ?";
      try {
         PreparedStatement pstmt = conn.prepareStatement(SQL);
         pstmt.setInt(1, commentID);
         return pstmt.executeUpdate();
      } catch (Exception e) {
         e.printStackTrace();
      }
      return -1; // �뜲�씠�꽣踰좎씠�뒪 �삤瑜�
   }
}